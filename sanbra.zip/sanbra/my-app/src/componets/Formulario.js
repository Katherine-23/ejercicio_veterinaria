import React, { useState } from 'react';
import { Modal, Text, StyleSheet, View, TextInput, ScrollView, Button } from 'react-native';

const Formulario = ({ modalVisible, guardarCita, setModalVisible, setNombreMascota, setNombreDueno }) => {
  const [paciente, setPaciente] = useState('');
  const [propietario, setPropietario] = useState('');
  const [email, setEmail] = useState('');
  const [telefono, setTelefono] = useState('');
  const [sintomas, setSintomas] = useState('');

  const handleGuardarCita = () => {
    guardarCita(); // Llama a la función guardarCita del componente App
    clearForm(); // Limpia los campos del formulario después de guardar la cita
  };

  const clearForm = () => {
    setPaciente('');
    setPropietario('');
    setEmail('');
    setTelefono('');
    setSintomas('');
  };

  return (
    <Modal animationType='slide' visible={modalVisible}>
      <View style={styles.contenido}>
        <ScrollView>
          <Text style={styles.titulo}>
            Nueva <Text style={styles.tituloBold}>Cita</Text>
          </Text>

          <View style={styles.campo}>
            <Text style={styles.label}>Nombre Paciente</Text>
            <TextInput
              style={styles.input}
              placeholder='Nombre del Paciente'
              placeholderTextColor='#666'
              onChangeText={text => setPaciente(text)}
              value={paciente}
            />
          </View>

          <View style={styles.campo}>
            <Text style={styles.label}>Nombre Propietario</Text>
            <TextInput
              style={styles.input}
              placeholder='Nombre del Propietario'
              placeholderTextColor='#666'
              onChangeText={text => setPropietario(text)}
              value={propietario}
            />
          </View>

          <View style={styles.campo}>
            <Text style={styles.label}>Email Propietario</Text>
            <TextInput
              style={styles.input}
              placeholder='Email'
              placeholderTextColor='#666'
              keyboardType='email-address'
              onChangeText={text => setEmail(text)}
              value={email}
            />
          </View>

          <View style={styles.campo}>
            <Text style={styles.label}>Telefono Propietario</Text>
            <TextInput
              style={styles.input}
              placeholder='Telefono Del Propietario'
              placeholderTextColor='#666'
              keyboardType='phone-pad'
              onChangeText={text => setTelefono(text)}
              value={telefono}
            />
          </View>

          <View style={styles.campo}>
            <Text style={styles.label}>Síntomas</Text>
            <TextInput
              style={[styles.input, styles.sintomasInput]}
              placeholder='Síntomas Paciente'
              placeholderTextColor='#666'
              onChangeText={text => setSintomas(text)}
              value={sintomas}
              multiline={true}
            />
          </View>

          <View style={styles.botones}>
            <Button title="Cancelar" onPress={() => setModalVisible(false)} />
            <Button title="Guardar Cita" onPress={handleGuardarCita} />
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  contenido: {
    backgroundColor: '#6D28D9',
    flex: 1,
    paddingVertical: 40,
    paddingHorizontal: 20,
  },
  titulo: {
    fontSize: 30,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
    color: '#fff',
  },
  tituloBold: {
    fontWeight: '900',
  },
  campo: {
    marginTop: 10,
  },
  label: {
    color: '#FFF',
    marginBottom: 10,
    fontSize: 20,
    fontWeight: '600',
  },
  input: {
    backgroundColor: '#FFF',
    padding: 15,
    borderRadius: 10,
  },
  sintomasInput: {
    height: 100,
  },
  botones: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
});

export default Formulario;
