import React, { useState } from 'react';
import { Text, View, StyleSheet, Pressable, Modal, TextInput } from 'react-native'; // Eliminé la importación del componente Button ya que no se usa
import Formulario from './src/componets/Formulario.js'; // Importa el componente Formulario desde su ubicación

export default function App() {
  const [modalVisible, setModalVisible] = useState(false);
  const [nombreMascota, setNombreMascota] = useState('');
  const [nombreDueno, setNombreDueno] = useState('');

  // Función para mostrar el modal
  const nuevaCita = () => {
    setModalVisible(true);
  };

  // Función para guardar la cita y cerrar el modal
  const guardarCita = () => {
    // Aquí puedes guardar la cita con la información ingresada por el usuario
    console.log('Guardando cita:', { nombreMascota, nombreDueno });
    // Después de guardar la cita, puedes cerrar el modal
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
        Administrador de Citas <Text style={styles.tituloBold}>veterinaria</Text>
      </Text>
      <Pressable onPress={nuevaCita} style={styles.nuevaCita}>
        <Text style={styles.btnTextNuevasCitas}>Nueva Cita</Text>
      </Pressable>

      <Modal animationType='slide' visible={modalVisible} onRequestClose={() => setModalVisible(false)}>
        <Formulario
          modalVisible={modalVisible}
          guardarCita={guardarCita}
          setModalVisible={setModalVisible}
          setNombreMascota={setNombreMascota}
          setNombreDueno={setNombreDueno}
        />
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#f3f4f6',
    flex: 1,
    padding: 0,
  },
  titulo: {
    margin: 24,
    fontSize: 30,
    textTransform: 'uppercase',
    fontWeight: '500',
    color: '#374151',
    textAlign: 'center',
  },
  tituloBold: {
    fontWeight: '500',
    color: '#6D2BD9',
  },
  nuevaCita: {
    backgroundColor: '#6D2BD9',
    padding: 15,
    marginTop: 30,
    marginLeft: 20,
    marginRight: 20,
    borderRadius: 50,
  },
  btnTextNuevasCitas: {
    textAlign: 'center',
    color: '#fff',
    fontSize: 20,
    fontWeight: '900',
    textTransform: 'uppercase',
  },
});
